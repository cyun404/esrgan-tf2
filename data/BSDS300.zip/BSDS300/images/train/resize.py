# -*- coding: utf-8 -*-
"""
Created on Sun Aug 15 18:11:15 2021

@author: YS
"""
import os
import glob
from PIL import Image

files = glob.glob('./*.jpg')

for f in files:
    try:
        img = Image.open(f)
        img_resize = img.resize((int((img.width+1) / 4), int((img.height+1) / 4)))
        title, ext = os.path.splitext(f)
        img_resize.save(title + '/4' + ext)
    except OSError as e:
        pass